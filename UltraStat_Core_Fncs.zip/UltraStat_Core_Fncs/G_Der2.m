function G_tilde_tilde_M = G_Der2(x,M1,t,Nt)

m = 3;
M_Omega = m*M1;

temp = Model_X1_Der_2(x,M1,t,Nt); % % 9*M x Nt
%g_der_2 = Bayes_Der_2b(x,M1,t',Nt);
g_der_2 = reshape(permute(temp,[2,1,3]),9*M1,Nt);

g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t') + kron(x((2*M1+1):(3*M1)),ones(1,Nt)),Nt,M1)')...
        .*exp(-reshape(kron(x((M1+1):2*M1),t'),Nt,M1)'));

g = g_model(x,M1,t,Nt);

temp1 = permute(reshape(g_der_2*g',M1,9,M1),[3,1,2]); % M1 x M1 x 9
temp1 = reshape(temp1,M1^2,9); % M1^2 x 9

G_temp1 = zeros(M1^2,M_Omega^2);

r = 1:M1; s = 1:M1; i = 0:1:2; j = 0:1:2;
[R,S,I,J] = ndgrid(r,s,i,j);

row1 = ((R-1)*M1 + S);
column1 = (S+I*M1-1)*M_Omega + (S+J*M1);
row2 = ((S-1)*M1 + R);
column2 = 3*I + J + 1;

ind1 = (column1 - 1)*M1^2 + row1;
ind2 = (column2 - 1)*M1^2 + row2;

G_temp1(ind1(:)) = temp1(ind2(:)); % note, the indices go top to bottom and then left to right

G_der_M1 = permute(reshape(G_temp1,M1,M1,M_Omega,M_Omega),[1,2,4,3]); % works, I think...

%temp4 = permute(reshape(g*g_der_2',M1,9,M1),[3,1,2]); % M1 x M1 x 9
temp4 = permute(reshape(g_der_2*g',M1,9,M1),[3,1,2]); % M1 x M1 x 9
temp4 = reshape(temp4,M1^2,9); % M1^2 x 9

G_temp4 = zeros(M1^2,M_Omega^2);

%r = 1:M1; s = 1:M1; i = 0:1:2; j = 0:1:2;
%[R,S,I,J] = ndgrid(r,s,i,j);

row1 = ((R-1)*M1 + S);
column1 = (R+I*M1-1)*M_Omega + (R+J*M1);
row2 = ((R-1)*M1 + S);
column2 = 3*I + J + 1;

ind1 = (column1 - 1)*M1^2 + row1;
ind2 = (column2 - 1)*M1^2 + row2;

G_temp4(ind1(:)) = temp4(ind2(:)); % note, the indices go top to bottom and then left to right

G_der_M4 = reshape(G_temp4,M1,M1,M_Omega,M_Omega); % works, I think...

%%%%

g_der_1 = Model_X1_Der_1(x,M1,t,Nt); % M x 3 (x,y,z); need to convert to M x M_Omega

temp2 = g_der_1*g_der_1';

G_temp2 = zeros(M1^2,M_Omega^2);

%r = 1:M1; s = 1:M1; i = 0:1:2; j = 0:1:2;
%[R,S,I,J] = ndgrid(r,s,i,j);

row1 = ((R-1)*M1 + S);
column1 = (R+I*M1-1)*M_Omega + (S+J*M1);
row2 = (I)*M1 + R;
column2 = (J)*M1 + S;

ind1 = (column1 - 1)*M1^2 + row1;
ind2 = (column2 - 1)*3*M1 + row2;

G_temp2(ind1(:)) = temp2(ind2(:)); % note, the indices go top to bottom and then left to right

G_der_M2 = reshape(G_temp2,M1,M1,M_Omega,M_Omega); % works, I think...


temp3 = g_der_1*g_der_1';

G_temp3 = zeros(M1^2,M_Omega^2);

%r = 1:M1; s = 1:M1; i = 0:1:2; j = 0:1:2;
%[R,S,I,J] = ndgrid(r,s,i,j);

row1 = ((R-1)*M1 + S);
column1 = (R+I*M1-1)*M_Omega + (S+J*M1);
row2 = (I)*M1 + R;
column2 = (J)*M1 + S;

ind1 = (column1 - 1)*M1^2 + row1;
ind2 = (column2 - 1)*3*M1 + row2;

G_temp3(ind1(:)) = temp3(ind2(:)); % note, the indices go top to bottom and then left to right

G_der_M3 = permute(reshape(G_temp3,M1,M1,M_Omega,M_Omega),[1,2,4,3]); % works, I think..

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

G_tilde_tilde_M = G_der_M1 + G_der_M2 + G_der_M3 + G_der_M4; % 

