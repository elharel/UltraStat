function g_der_2 = Model_X1_Der_2(x,M1,t,Nt)

% This function calculates the second derivatives of the model functions
% \Omega = [omega_1 ... omega_M gamma_1 ... gammm_M phase_1 ... phase_M]
% g_der_2_ij = d^2g(\Omega)\d(\Omega_i)\d(\Omega_j).  Reduces the
% computational cost compared to Bayes_Der_2

%M_Omega = 3*M1;

x_vec1 = kron(x(1:M1),t');
x_vec2 = kron(x((M1+1):2*M1),t');
x_vec3 = kron(x((2*M1+1):(3*M1)),ones(1,Nt));

cos_term = cos(2*pi*x_vec1 + ...
    x_vec3);
exp_term = exp(-x_vec2);
sin_term = sin(2*pi*x_vec1 + ...
    x_vec3);
t_term = kron(ones(1,M1),t');

cos_exp_term = cos_term.*exp_term;
sin_exp_term = sin_term.*exp_term;
t_term_2 = t_term.^2;

g_der_2 = zeros(9,M1,Nt);

g_der_2(1,:,:) = reshape((-(2*pi)^2.*t_term_2.*cos_exp_term),Nt,M1)'; % d^2 g / d_omega / d_omega

g_der_2(2,:,:) = reshape((2*pi*t_term_2.*sin_exp_term),Nt,M1)'; % d^2 g / d_omega / d_omega

g_der_2(3,:,:) = reshape((-2*pi*t_term.*cos_exp_term),Nt,M1)';

g_der_2(4,:,:) = g_der_2(2,:,:); %reshape((t_term.*(2*pi*t_term).*sin_term.*exp_term),Nt,M1)';

g_der_2(5,:,:) = reshape((t_term_2.*cos_exp_term),Nt,M1)';

g_der_2(6,:,:) = reshape((t_term.*sin_exp_term),Nt,M1)';

g_der_2(7,:,:) = g_der_2(3,:,:); %reshape((-2*pi*t_term.*cos_term.*exp_term),Nt,M1)';

g_der_2(8,:,:) = g_der_2(6,:,:); %reshape((t_term.*sin_term.*exp_term),Nt,M1)';

g_der_2(9,:,:) = reshape((-cos_exp_term),Nt,M1)';

% g_der_2 = [gfunc_sin_der2_11_M;gfunc_sin_der2_12_M;gfunc_sin_der2_13_M;...
%     gfunc_sin_der2_21_M;gfunc_sin_der2_22_M;gfunc_sin_der2_23_M;...
%     gfunc_sin_der2_31_M;gfunc_sin_der2_32_M;gfunc_sin_der2_33_M];

% [M1xNt;M1xNt;M1xNt ...] M elements, 9 times (xx,xy,xz,yx,yy,yz,zx,zy,zz)
