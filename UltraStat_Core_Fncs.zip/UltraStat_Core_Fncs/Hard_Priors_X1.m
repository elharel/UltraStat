function [prior_log, grad_prior_log, hess_prior_log] = Hard_Priors_X1(x,M,Phi_min,Phi_max)

m = 3; % number of parameters per model function

% only for the parameters (not the amplitudes!)
% these priors assumes a normal PDF 
% note, we are calculating the -log of the prior here...

%prior_log = 0;
grad_prior_log = zeros(m*M,1);
hess_prior_log = zeros(m*M,3*M);

% freq_M = x(1:M);
% gamma_M = x((M+1):2*M);
% phase_M = x((2*M+1):3*M);

% 1. Priors on freq, decay/gamma, and phase

%c1 = sum(log(sqrt(2*pi)*sigfreq0)); 
%c2 = sum(log(sqrt(2*pi)*siggamma0)); 
%c3 = sum(log(sqrt(2*pi)*siggamma0)); 

% prior_log = prior_log + sum((freq_M - freq0).^2./(2*sigfreq0.^2));% - sqrt(2*pi)*sigfreq0;
% prior_log = prior_log + sum((gamma_M - gamma0).^2./(2*siggamma0.^2)); % - sqrt(2*pi)*siggamma0;
% prior_log = prior_log + sum((phase_M - phase0).^2./(2*sigphase0.^2)); % - sqrt(2*pi)*sigphase0;
% %prior_log = prior_log - sum((B - amp0).^2./(2*sigamp0.^2)); % - sqrt(2*pi)*sigamp0;

if all(x <= Phi_max) && all(x >= Phi_min)
    prior_log = 0;
else 
    prior_log = 1e6;
end

% 2. Priors on the amplitude
if nargout > 1
    % grad_prior_log(1:M) = (freq_M - freq0)./(sigfreq0.^2);
    % grad_prior_log((M+1):2*M) = (gamma_M - gamma0)./(siggamma0.^2);
    % grad_prior_log((2*M+1):3*M) = (phase_M - phase0)./(sigphase0.^2);

    % grad_prior_log = zeros(3*M,1);
    %amp_der1 = Bayes_amp_der1(x,M,t,Nt,S_t,epsilon);
    %grad_prior_log = grad_prior_log - ((B - amp0)*amp_der1/(sigamp0^2))';
end

if nargout > 2

    % hess_prior_log(1:M,1:M) = diag(1./(sigfreq0.^2));
    % hess_prior_log((M+1):2*M,(M+1):2*M) = diag(1./(siggamma0.^2));
    % hess_prior_log((2*M+1):3*M,(2*M+1):3*M) = diag(1./(sigphase0.^2));
    %hess_prior_log = eye(3*M);
    %hess_prior_log = zeros(3*M,3*M);
    %amp_der2 = Bayes_amp_der2(x,M,t,Nt,S_t,epsilon);
    %amp_der2_flat = reshape(amp_der2,M,9*M^2);

    %temp1 = reshape(2*(B - amp0)*amp_der2_flat,3*M,3*M);
    %temp2 = 2*(amp_der1'*amp_der1);
    %hess_prior_log = hess_prior_log - temp1/(2*sigamp0^2) - temp2/(2*sigamp0^2);

end



 
