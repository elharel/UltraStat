function [gfunc_der,M_Phi_D] = Model_X1_Der_1(x,M,t,Nt)

% This function calculates the first derivative of the model functions
% cos(reshape(2*pi*kron(x(1:M1),t) + kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
        %.*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1));
% \Phi = [omega_1 ... omega_M gamma_1 ... gammm_M phase_1 ... phase_M]
% g_der_1_i = dg(\Omega)\d(\Omega_i)

% derivative with respect to omega (Phi_1:Phi_M)

t_vec1 = kron(ones(1,M),t'); %t
x_vec1 = kron(x(1:M),t'); %w*t
x_vec3 = kron(x((2*M+1):(3*M)),ones(1,Nt)); %phi
x_vec2 = -kron(x((M+1):2*M),t'); %-gamma*t

gfunc_der_omega = reshape((-2*pi*t_vec1.*sin(2*pi*x_vec1 + ...
    x_vec3).*exp(x_vec2)),Nt,M)';

% derivative with respect to gamma (Phi_(M+1):Phi_2*M)
gfunc_der_gamma = reshape((-t_vec1.*cos(2*pi*x_vec1 + ...
    x_vec3).*exp(x_vec2)),Nt,M)';

% derivative with respect to phi (Phi_(2*M+1):Phi_3*M)
gfunc_der_phi = reshape((-sin(2*pi*x_vec1 + ...
    x_vec3).*exp(x_vec2)),Nt,M)';


m = 3;


gfunc_der = [gfunc_der_omega;gfunc_der_gamma;gfunc_der_phi];

if nargout > 1

    M_Phi_D = zeros(Nt,M,m*M);

    I = 1:M;
    J = 1:M;

    index1_1 = sub2ind([M,m*M],I,J);
    index2_1 = sub2ind([M,m*M],I,J+M);
    index3_1 = sub2ind([M,m*M],I,J + 2*M);

    M_Phi_D(:,index1_1) = gfunc_der_omega';
    M_Phi_D(:,index2_1) = gfunc_der_gamma';
    M_Phi_D(:,index3_1) = gfunc_der_phi';

end

