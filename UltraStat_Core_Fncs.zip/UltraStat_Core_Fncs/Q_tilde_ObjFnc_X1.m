function [Q_tilde, Jac, Hess] = ...
    Q_tilde_ObjFnc_X1(x0,M,t,Nt,S_t,epsilon,varargin)

% uses Model X1 (damped oscillatory functions)
% 3 parameters per function: omega, gamma, phi
% generalized to suite any size S_t (N x N_r)
% optimized for large values of N_r (>1000, <10000)
% varargin = [S_t_norm,...]
Jac = [];

N_r = size(S_t,2);

if isempty(varargin)
    S_t_norm = sum(S_t(:).^2);
else
    S_t_norm = varargin{1};
end


m = 3;
M_Omega = m*M;

v_M_Omega = ones(1,M_Omega);
V_M_Omega = ones(M_Omega,M_Omega);


m = 3; %  number of parameters per model function

g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t) + ...
    kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
    .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));

M_Phi = g_model(x0,M,t,Nt); % N x M

R = M_Phi'*S_t; % M*S; M x N_r % FAST

V = S_t'*M_Phi;

G = M_Phi'*M_Phi + epsilon*eye(M); % M x M

term1 = R*V/G; % N x N * N x N_r = N x N_r


Q_tilde = S_t_norm - trace(term1); % sum(S_t(:).^2) - sum(S_t.S_rec);

if nargout > 1

    G_inv = inv(G); % could this be replaced with truncated SVD or regularized?

    [gfunc_der,M_Phi_M_tilde] = Model_X1_Der_1(x0,M,t,Nt); % Nt x M x M_Omega


    V_nabla = zeros(N_r,M,M_Omega); % S*M'; N_r x M x M_Omega

    IND = sub2ind([M,M_Omega],[1:M 1:M 1:M],1:M_Omega);
    V_nabla(:,IND) = (gfunc_der*S_t)';

    M_Phi_M = reshape(kron(v_M_Omega,M_Phi),Nt,M,M_Omega); % Nt x M x M_Omega
    G_inv_M = reshape(kron(v_M_Omega,G_inv),M,M,M_Omega);
    G_M_tilde = pagemtimes(M_Phi_M,'transpose',M_Phi_M_tilde,'none') + ...
        pagemtimes(M_Phi_M_tilde,'transpose',M_Phi_M,'none'); % G'

    G_inv_M_tilde = -pagemtimes(pagemtimes(G_inv_M,G_M_tilde),G_inv_M); % G^-1'

    Q_tilde_Jac = zeros(M_Omega,1);
    
    B_tilde = zeros(N_r,M,M_Omega);

    for i = 1:M_Omega
        B_tilde(:,:,i) = V_nabla(:,:,i)*G_inv + (G_inv_M_tilde(:,:,i)*R)'; % N_r x M x M_Omega
        term1 = R*V_nabla(:,:,i)*G_inv;
        term2 = R*V*G_inv_M_tilde(:,:,i);
        temp = -2*term1 - term2;
        Q_tilde_Jac(i) = trace(temp);
    end
    
    Jac{1} = Q_tilde_Jac;
    B_tilde = pagemtimes(V_nabla,G_inv) + pagemtimes(V,G_inv_M_tilde);
    Jac{2} = B_tilde; % grad B 
end

if nargout > 2

    gfunc_der2 = Model_X1_Der_2(x0,M,t,Nt); % 9 x M x Nt

    V_nabla2 = zeros(N_r,M,M_Omega,M_Omega); % N_r x M x M_Omega x M_Omega

    temp = reshape(gfunc_der2,M*m^2,Nt);

    [Im,Vm,Sm] = ndgrid(1:M,0:(m-1),0:(m-1));
    ind1 = Im; ind2 = Im + Sm*M; ind3 = Im + Vm*M;
    IND_1 = sub2ind([M,M_Omega,M_Omega],ind1,ind2,ind3);

    [Im,SVm] = ndgrid(1:M,1:m^2);
    ind1 = SVm; ind2 = Im;
    IND_2 = sub2ind([m^2,M],ind1,ind2);

    V_nabla2(:,IND_1) = (temp(IND_2,:)*S_t)';

    G_inv_M2 = permute(reshape(kron(V_M_Omega,G_inv),M,M_Omega,M,M_Omega),[1,3,2,4]);

    V_nabla_s = V_nabla;

    V_nabla_v = V_nabla_s;

    G_tilde = reshape(G_M_tilde,M^2,M_Omega);
    G_tilde_M_s = permute(reshape(kron(v_M_Omega,G_tilde),M,M,M_Omega,M_Omega),[1,2,3,4]); % G' (M x M x M_Omega x M_Omega)
    G_tilde_M_v = permute(G_tilde_M_s,[1,2,4,3]);

    G_inv_nabla_s = -pagemtimes(pagemtimes(G_inv_M2,G_tilde_M_s),G_inv_M2);

    R_nabla_s = permute(V_nabla_s,[2,1,3]);
    %R_nabla_v = permute(V_nabla_v,[2,1,3]);
    %R_nabla2 = permute(V_nabla2,[2,1,3,4]);

    G_inv_nabla_v = permute(G_inv_nabla_s,[1,2,4,3]);

    G_tilde_tilde_M = G_Der2(x0,M,t,Nt); % 3 ms

    term1 = (pagemtimes(pagemtimes(G_inv_nabla_s,G_tilde_M_v),'none',G_inv_M2,'none')); % G_inv'(l) G'(p) G_inv
    term2 = (pagemtimes(pagemtimes(G_inv_M2,G_tilde_tilde_M),'none',G_inv_M2,'none')); % G_inv G''(l,p) G_inv
    term3 = (pagemtimes(pagemtimes(G_inv_M2,G_tilde_M_v),'none',G_inv_nabla_s,'none')); % G_inv G'(p) G_inv'(l)

    G_inv_nabla2 = -(term1 + term2 + term3);

    Q_tilde_Hess = zeros(M_Omega,M_Omega);

    F11 = pagemtimes(R,V_nabla2);
    F22 = pagemtimes(R*V,G_inv_nabla2);
    F12 = pagemtimes(R,V_nabla_v);
    F13 = pagemtimes(V_nabla_v,G_inv);
    F23 = pagemtimes(R_nabla_s,V);
    
    % this could be sped up; there are duplicate calculations here...
    
    %F31 = pagemtimes(G_inv_nabla2,R);
    F31 = pagemtimes(V,G_inv_nabla2);
    %F32 = pagemtimes(G_inv_nabla_s,R_nabla_v);
    F32 = pagemtimes(V_nabla_s,G_inv_nabla_v);
    %F33 = pagemtimes(G_inv_nabla_v,R_nabla_s);
    %F33 = pagemtimes(V_nabla_v,G_inv_nabla_s);
    F33 = permute(F32,[1,2,4,3]);
    %F34 = pagemtimes(G_inv,R_nabla2);
    F34 = pagemtimes(V_nabla2,G_inv);

    %B_tilde_tilde = permute(F31 + F32 + 0*F33 + 0*F34,[2,1,3,4]);
    B_tilde_tilde = (F31 + F32 + F33 + F34);
    %B_tilde = pagemtimes(V_nabla,G_inv) + pagemtimes(V,G_inv_M_tilde);
    %Jac{2} = B_tilde;

    for j = 1:M_Omega
        for i = 1:M_Omega

            term11 = F11(:,:,i,j)/G;
            term12 = F12(:,:,j)*G_inv_nabla_s(:,:,i,j);
            term13 = R_nabla_s(:,:,i)*F13(:,:,j);
            term21 = F12(:,:,i)*G_inv_nabla_v(:,:,i,j);
            term22 = F22(:,:,i,j);
            term23 = F23(:,:,i)*G_inv_nabla_v(:,:,i,j);
            temp =  -2*(term11 + term12 + term13) - 1*(term21 + term22 + term23);
            Q_tilde_Hess(i,j) = sum(diag(temp));

        end
    end

   Hess{1} = Q_tilde_Hess;
   Hess{2} = B_tilde_tilde;


end
