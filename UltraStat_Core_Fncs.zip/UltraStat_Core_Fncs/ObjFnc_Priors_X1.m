function [f,g,H] = ObjFnc_Priors_X1(x0,M,t,Nt,S_t,epsilon,...
    Phi_min,Phi_max,sigstd,varargin)

% objective function for model X2 (includes time zero as one of the
% parameters)
% The objective function is now defined for a signal of size N x N_r
% We will assume Gaussian priors so that all the parameters and amplitudes
% are drawn from a PDF defined by a mean and variance (sigma^2).  Note, to
% properly account for the noise, we can replace S_t with S_t/sigmanoise.
% This should be done to the input of this objective so that we don't need
% to calculate each time we run this function...

g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t) + ...
    kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
    .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));

%m = 3;
%M_Omega = m*M + 1;

%amp_prior_1_wt = 0;
%amp_prior_2_wt = 1e-3;
Phi_prior_1_wt = 1;

if isempty(varargin)
    %amp0 = 0; sigamp0 = inf;
    B = 0;
    amp_prior = 0;
    amp_prior_2_wt = 0;
else
    %amp0 = varargin{1}; sigamp0 = varargin{2};
    amp_prior_2_wt = varargin{1};
    g = g_model(x0,M,t,Nt);
    B = g\S_t; % M x N_r
    %amp_prior = amp_prior_1_wt*sum(sum((B - amp0).^2,1),2)/(2*sigamp0^2); % l2 regularization;
    amp_prior = amp_prior_2_wt*sum(abs(B(:))); %l1 regularization
    % how do we impose a penalty for negative B?

    %N_r = size(B,2);
end

Q_tilde = Q_tilde_ObjFnc_X1(x0,M,t,Nt,S_t,epsilon);

%prior_log = 0;
%prior_log = Normal_Priors_1(x0,M,Phi_mean,Phi_sigma) + amp_prior;
%prior_log = Phi_prior_1_wt*Normal_Priors_1(x0,M,Phi_mean,Phi_sigma) + amp_prior;
prior_log = Phi_prior_1_wt*Hard_Priors_X1(x0,M,Phi_min,Phi_max) + amp_prior;
% note: Normal_Priors_1 does not include the time zero parameter...

% Evaluate objective function
%f = Q_tilde/(2*sigvar) + prior_log; % Q_tilde/2*sigvar should be about 1/2
%(I think).  
% chi = Q_tilde/((Nt*N_r-1)*sigvar) is ~1.  This means we can then scale
% the priors relative to '1'

%f = Q_tilde/(2*sigstd^2) + prior_log; % -log; like Q_tilde'
f = Q_tilde/((Nt-1)*sigstd^2) + prior_log; % -log; like Q_tilde'


% Evaluate the gradient.
if nargout > 1

    %grad_prior_log = 0;
    %[~, grad_prior_log] = Normal_Priors_1(x0,M,Phi_mean,Phi_sigma);
    [~, grad_prior_log] = Hard_Priors_X1(x0,M,Phi_min,Phi_max);
    [~, Jac] = Q_tilde_ObjFnc_X1(x0,M,t,Nt,S_t,epsilon);
    Q_tilde_Jac = Jac{1}; 
    
    if isempty(varargin)
        %B_grad = 0;
        amp_grad_prior_log = 0;
    else
        B_grad = permute(Jac{2},[2,1,3]); % same as R_nabla, M x N_r x M_Omega
        %B_grad_sign = sign(B)*B_grad;
        %amp_grad_prior_log = tensorprod(B-amp0,B_grad,[1,2]);
        amp_grad_prior_log = tensorprod(sign(B),B_grad,[1,2]);
    end
    
    g = Q_tilde_Jac/((Nt-1)*sigstd^2) + Phi_prior_1_wt*grad_prior_log + amp_prior_2_wt*amp_grad_prior_log;
        %amp_prior_1_wt*amp_grad_prior_log; % - ((B - amp0)*B_grad/(sigamp0^2))';
    % B is M x N_r, B_grad is M x N_r x M_Omega
end
%
% Evaluate the Hessian matrix
if nargout > 2

    %hess_prior_log = 0;
    %[~, ~, hess_prior_log] = Normal_Priors_1(x0,M,Phi_mean,Phi_sigma);
    [~, ~, hess_prior_log] = Hard_Priors_X1(x0,M,Phi_min,Phi_max);
    [~, ~, Hess] = Q_tilde_ObjFnc_X1(x0,M,t,Nt,S_t,epsilon);
    Q_tilde_Hess = Hess{1}; 
    
    if isempty(varargin)
        %B_grad2 = 0;
        amp_hess_prior_log = 0;
    else
        B_grad2 = permute(Hess{2},[2,1,3,4]); % nabla^2 of B
        % term1 = tensorprod(B-amp0,B_grad2,[1,2]); % eqn 2.39
        % temp1 = zeros(1,M_Omega,N_r,M);
        % temp1(1,:,:,:) = permute(B_grad,[3,2,1]);
        % temp2 = pagemtimes(temp1,'transpose',temp1,'none');
        % term2 = sum(sum(temp2,3),4);
        % amp_hess_prior_log = (term1 + term2)/(sigamp0^2); % numbers seem very large...
        amp_hess_prior_log = tensorprod(sign(B),B_grad2,[1,2]);
    end
    
   
    H = Q_tilde_Hess/((Nt-1)*sigstd^2) + 1*Phi_prior_1_wt*hess_prior_log + amp_prior_2_wt*amp_hess_prior_log;
    %...
     %   amp_prior_1_wt*amp_hess_prior_log;
    % B is M x N_r, B_grad2 is M x N_r x M_Omega x M_Omega
end

end