%% Test ObjFnc_Priors_X1.m
cd('C:\Users\Elad Harel\Dropbox\Work\MSU\Shared\Elad\Matlab\UltraStat\UltraStat_Shared_v2\');

clear all

dt = 20e-3;
Nt = 1e3;
Fs = 1/dt;
t = 0:dt:(Nt-1)*dt;
t = t';
dv = 1/dt/Nt; v_max = (1/dt - 1/dt/Nt);
v = 0:dv:v_max;
v = v';

%phase0 = 0;
%sigphase0 = pi/4;
tz = 0.0;

freq_M_coh =  [0.15 1 2.5 10 10.25 13 5 5.5];
phase_M_coh = [0 0 0 0 0 0 0 0];
gamma_M_coh = [0.1 0.025 0.3 0.5 0.5 0.7 0.25 0.7];
amp_M_coh =   [1 0.2 0.7 0.5 2 0.5 0.5 1];

freq_M_pop =  [0 0];
phase_M_pop = [0 0];
gamma_M_pop = [1 3.5];
amp_M_pop =   [40 20];

M_coh = length(freq_M_coh);
M_pop = length(freq_M_pop);

M = M_coh + M_pop;

x_GT = [freq_M_pop freq_M_coh gamma_M_pop gamma_M_coh phase_M_pop phase_M_coh];
%phase_M = normrnd(phase0,sigphase0,[1,M]);

S_t_orig_coh = 0;
for i = 1:M_coh
    %S_t = S_t + amp_M(i)*cos(2*pi*freq_M(i)*t + phase_M(i)).*exp(-decay_M(i)*t);
    S_t_orig_coh = S_t_orig_coh + amp_M_coh(i)*exp(1i*2*pi*freq_M_coh(i)*(t-tz) + 1i*phase_M_coh(i)).*exp(-gamma_M_coh(i)*t);
end

S_t_orig_pop = 0;
for i = 1:M_pop
    %S_t = S_t + amp_M(i)*cos(2*pi*freq_M(i)*t + phase_M(i)).*exp(-decay_M(i)*t);
    S_t_orig_pop = S_t_orig_pop + amp_M_pop(i)*exp(1i*2*pi*freq_M_pop(i)*(t-tz) + 1i*phase_M_pop(i)).*exp(-gamma_M_pop(i)*t);
end

S_t_0 = real(S_t_orig_coh + S_t_orig_pop);
% larger time zero, the more sensitive the algorithm is to the phase...
% This is why X2 may work better...
% Or we may want a hybrid method, that has eliminates the phase term for
% one of the components.  This way, we still have 3*M parameters (1 for tz
% and 3M-1 for the remaining parameters...).  The other advantage of this
% approach is that we can use a good prior for the phase. 
% The model would then be something like this: 

% g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t - x(end)) + ...
%     kron([x((2*M1+1):(3*M1-1)),0],ones(Nt,1)),Nt,M1))...
%     .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));
%%
sigstd = 0.4; %sigstd = 1e-2;
a_noise = normrnd(0,sigstd,[Nt,1]);

S_t = S_t_0 + a_noise;

fo = fitoptions('Method','NonlinearLeastSquares',...
    'Lower',[0,0.1,0,0.1,0],...
    'Upper',[inf,10,inf,10,inf],...
    'StartPoint',[max(S_t) 0.5 0 0.5 S_t(end)]);

ft = fittype('a*exp(-b*x) + c*exp(-d*x) + e','options',fo);


[curve2,gof2] = fit(t,S_t,ft);
gof2.rsquare;

figure(1); clf
plot(t,S_t); hold on
plot(t,curve2(t),'linewidth',2)
%%
%freq0 = 0; sigfreq0 = 15; gamma0 = 0; siggamma0 = 4; phase0 = 0; sigphase0 = 0.01;
Phi_min = [0 0.005 0];
Phi_max = [15 6 inf];

k_max = 10;


Phi_bnds = [Phi_min;Phi_max];

M_pop0 = 2;
x0 = [0 0 curve2.b curve2.d 0 0];

GlobalOptions = optimoptions('simulannealbnd', 'Display', ...
                'iter', 'MaxIterations', 2000,'FunctionTolerance',1e-3,...
                'MaxFunctionEvaluations',2000);

LocalOptions = optimoptions('fmincon', 'Algorithm', 'trust-region-reflective', 'SpecifyObjectiveGradient', true, ...
                'HessianFcn', 'objective', 'StepTolerance', 1e-10, 'FunctionTolerance', 1e-3, 'MaxIterations', 3000, ...
                'MaxFunctionEvaluations', 2000,'display','iter');

opt_options{1} = GlobalOptions;
opt_options{2} = LocalOptions;



% g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t - x(end)) + ...
%     kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
%     .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));
% 
% phase_M2 = mod(-2*pi*freq_M + phase_M,2*pi);
% x2 = [freq_M decay_M phase_M2 0];
% 
% g = g_model(x2,M_coh,t,Nt);
% B2 = g\S_t;
% 
% S_t2 = g*B2;
%


tic
[x_local_X1, M_Bayes_vec, std_vec] = Bayes_X1_opt(t,S_t,v,k_max,...
                        Phi_bnds,Phi_min,Phi_max,sigstd,x0,M_pop0,opt_options,0,1);
toc
% x_local_X2 = Bayes_X2_opt(t,S_t,v,M_max,...
%                         Phi_bnds,Phi_mean0,Phi_sigma0,sigstd,x0,M_pop0,opt_options,1,1);
% Choose optimal 'M' value




%% sort and select optimal




%%
figure(2); clf
% Plot Results; 

%[~, ~, Hess] = Q_tilde_ObjFnc_X2(x_GT,3,t,Nt,S_t,1e-9);
% one interesting thing is that the order in which it finds the peaks seems
% to matter...  sometimes it finds a correct peak, but does so later.  In
% other words, it may make sense to order the peak selection by the
% gradient of the iteration.  That is, in order of the delta of the
% residual


k_eval = 10;
x_opt = x_local_X1{k_eval};
M_opt = M_pop0 - 1 + k_eval;
[Phi_param, Phi_error, S_rec] = Bayes_parameters_X1(x_opt,M_opt,t,S_t,Nt,Phi_min,Phi_max);
%Phi_error
%[Phi_param, Phi_error] = Bayes_parameters_X1(x_GT,6,t,S_t,Nt,Phi_min,Phi_max);
% Phi_mean = [freq0*ones(1,M_coh) gamma0*ones(1,M_coh) phase0*ones(1,M_coh)];
% Phi_sigma = [sigfreq0*ones(1,M_coh) siggamma0*ones(1,M_coh) sigphase0*ones(1,M_coh)];
% 
% [f,~,~] = ObjFnc_Priors_X1(x_GT,6,t,Nt,S_t,epsilon,...
%     Phi_mean,Phi_sigma,sigstd,1)

lorfunc2 = @(x0,gamma,phi,tz,v)exp(1i*(phi - 2*pi*x0*tz))*(1 - 1i*(2*pi*(v - x0) / gamma)) ./ (1 + (2*pi*(v - x0) / gamma).^2)/gamma;
mf = 64; % factor to increase spectral resolution in the 'analytical' FT
%dt = 10e-3;
v_HR = 0:1/dt/mf/Nt:(1/dt - 1/dt/mf/Nt); % h

S_spec_Bayes = zeros(mf*Nt,M_opt);
freq_Bayes = Phi_param.freq; freq_error = Phi_error.freq;
gamma_Bayes = Phi_param.gamma; gamma_error = Phi_error.gamma;
phase_Bayes = Phi_param.phase; phase_error = Phi_error.phase;

amp_Bayes = Phi_param.amp; amp_error = Phi_error.amp;

[I,J] = sort(freq_Bayes);
freq_Bayes = freq_Bayes(J); freq_error = freq_error(J);
gamma_Bayes = gamma_Bayes(J); gamma_error = gamma_error(J);
phase_Bayes = phase_Bayes(J); phase_error = phase_error(J);
amp_Bayes = amp_Bayes(J); amp_error = amp_error(J);


[I_coh,J_coh] = find(freq_Bayes > 0.05 & gamma_Bayes < 2);
M_Bayes_coh = length(J_coh);

freq_Bayes_coh = freq_Bayes(J_coh); freq_error_coh = freq_error(J_coh);
gamma_Bayes_coh = gamma_Bayes(J_coh); gamma_error_coh = gamma_error(J_coh);
phase_Bayes_coh = phase_Bayes(J_coh); phase_error_coh = phase_error(J_coh);
amp_Bayes_coh = amp_Bayes(J_coh); amp_error_coh = amp_error(J_coh);

for i = 1:M_Bayes_coh
    S_spec_Bayes(:,i) = amp_Bayes_coh(i)*...
        lorfunc2(freq_Bayes_coh(i),gamma_Bayes_coh(i),0,0,v_HR);
        %lorfunc2(freq_Bayes_coh(i),gamma_Bayes_coh(i),phase_Bayes_coh(i),x_opt(end),v_HR);
end


S_spec_GT = zeros(mf*Nt,M_coh);

for i = 1:M_coh
    S_spec_GT(:,i) = amp_M_coh(i)*lorfunc2(freq_M_coh(i),gamma_M_coh(i),0,0,v_HR);
end

clf
subplot(2,2,[1,2])
plot(t,S_t,'b.-','linewidth',1); hold on
plot(t,S_rec,'g','linewidth',2)
set(gca,'fontsize',14,'ytick','')
axis([0 20 -inf inf])
xlabel('{\Delta}T (ps)')

subplot(2,2,[3,4])

ar_GT = area(v_HR,abs(sum(S_spec_GT,2)),'linewidth',2); hold on
alpha(ar_GT,0.25)
ar_GT.FaceColor = 'none';
ar_GT.EdgeColor = 'r';
%area(v_mol_es,abs(S_spec_Bayes(k,:)),'linewidth',2); hold on

for k = 1:M_Bayes_coh
    ar = area(v_HR,abs((S_spec_Bayes(:,k))),'linewidth',1); hold on
    alpha(ar,0.5)
    ar.FaceColor = 'g';
end

include_error_flag = 1;
if include_error_flag ~= 0
    errorbar(freq_Bayes_coh,abs(amp_Bayes_coh)./gamma_Bayes_coh,amp_error_coh./gamma_Bayes_coh,'k.','linewidth',1)
    errorbar(freq_Bayes_coh,abs(amp_Bayes_coh)./gamma_Bayes_coh,...
        freq_error_coh,'horizontal','b.','linewidth',1)
end
%str_empty_error = strings(1,1);
str_empty_coh = strings(1,length(freq_Bayes_coh)-1);

plot(v,2*abs(fft(S_t - curve2(t)))/Fs,'b','linewidth',1)
plot(v_HR,abs(sum(S_spec_Bayes,2)),'k--','linewidth',2)

stem(freq_M_coh,0*ones(1,M_coh),'markerfacecolor','r','markersize',8)
set(gca,'fontsize',14,'ytick','')
axis([0 20 -inf inf])
xlabel('v (THz)')

legend(['GT','Bayes',strings(1,10),'FFT'])