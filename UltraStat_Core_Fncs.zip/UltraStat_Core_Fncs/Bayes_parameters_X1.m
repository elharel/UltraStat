function [Phi_param, Phi_error, S_rec] = Bayes_parameters_X1(x,M,t,S_t,Nt,Phi_min,Phi_max)

% Extract parameters from the optimal solution, x, from the optimization
% routine.  Calculates the errors for the parameters and amplitudes.
Phi_param = [];
Phi_error = [];

g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t) + ...
    kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
    .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));

g_rec = g_model(x,M,t,Nt);

B_rec = g_rec\S_t;  % errors introduced here by recovering amplitudes with original signal!

%x = B_rec;

S_rec = g_rec*B_rec;
S_res = S_t - S_rec;

sigvar = std(S_res(:));
% calculate errors
G = g_rec'*g_rec;
[V,D] = eig(G);

temp = 0;

for l = 1:M
   
    temp = temp + V(l,:).^2./D(l,l);

end

amp_error = sigvar.*sqrt(temp);

%Phi_min0 = [Phi_min(1)*ones(1,M) Phi_min(2)*ones(1,M) Phi_min(3)*ones(1,M)];
%Phi_max0 = [Phi_max(1)*ones(1,M) Phi_max(2)*ones(1,M) Phi_max(3)*ones(1,M)];

% freq0 = Phi_mean0(1); sigfreq0 = Phi_sigma0(1); 
% gamma0 = Phi_mean0(2); siggamma0 = Phi_sigma0(2); 
% phase0 = Phi_mean0(3); sigphase0 = Phi_sigma0(3);...
% 
% %freq0 = 0; sigfreq0 = inf; gamma0 = 0; siggamma0 = inf; phase0 = 0; sigphase0 = inf;
% Phi_mean = [freq0*ones(1,M) gamma0*ones(1,M) phase0*ones(1,M)];
% Phi_sigma = [sigfreq0*ones(1,M) siggamma0*ones(1,M) sigphase0*ones(1,M)];



[~, ~, Hess_set] = ...
    Q_tilde_ObjFnc_X1(x,M,t,Nt,S_t,1e-9);

%[~, ~, Hess_set] = ObjFnc_Priors_X1(x,M,t,Nt,S_t,1e-9,Phi_min0,Phi_max0,sigvar);



B = 0.5*Hess_set{1}; % 

[V2,D2] = eig(B);


temp = 0;
%temp_v = zeros(3*M+1,3*M+1);
% rank of B is wrong... 
% the error explodes when I include the last 'tz' term...

for l = 1:(3*M) %(3*M + 1)
    %temp_v(l,:) = V2(l,:).*conj(V2(l,:))./(D2(l,l));
    temp = temp + V2(l,:).*conj(V2(l,:))./(D2(l,l));

end

%Phi_error_vec = 0.5*abs(sqrt(temp)); % not sure about the 'abs' part of this...
Phi_error_vec = sigvar*0.5*abs(sqrt(temp));

freq_Bayes = x(1:M); freq_error = Phi_error_vec(1:M);
gamma_Bayes = x((M+1):2*M); gamma_error = Phi_error_vec((M+1):2*M);
phase_Bayes = x((2*M+1):3*M); phase_error = Phi_error_vec((2*M+1):3*M);

amp_Bayes = B_rec';

Phi_param.freq = freq_Bayes;
Phi_param.gamma = gamma_Bayes;
Phi_param.phase = phase_Bayes;

Phi_param.amp = amp_Bayes;

Phi_error.freq = freq_error;
Phi_error.gamma = gamma_error;
Phi_error.phase = phase_error;

Phi_error.amp = amp_error;
