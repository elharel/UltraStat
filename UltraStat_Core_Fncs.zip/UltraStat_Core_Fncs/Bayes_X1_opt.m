function [x_local_X, M_Bayes_vec, std_vec] = Bayes_X1_opt(t,S_t,v1,k_max,...
                        Phi_bnds,Phi_min,Phi_max,sigstd,x0,M_pop0,opt_options,varargin)

% This function runs the Bayes optimization algorithm.  't' and 'S_t' are
% the time axes and signal, respectively.  M_max is the maximum number of
% iterations (i.e. features in the signal).  Phi_bnds are the lower and
% upper bounds for the parameters used by the optimization solvers.
% Phi_mean and Phi_sigma are the priors.  Sigvar is the variance of the
% noise (if known).  x0 is the starting point for the solvers.  Typically,
% this would contain the results of a multi-exponential fit to the data.
% M_pop0 are the number of terms in the multi-exponential fit.

% Opt_options are options used by the local and global solvers.  Varargin
% are additional arguments for the amplitude priors. If empty, no amplitude
% priors are used.  If not, varargin = [amp_prior,plot_flag], which can 
% take on values of 1 or 0.

% Note, this version works on model type X2 (3 parameters: freq, decay, and
% phi, plus one additional term for time zero.  If time zero is known or
% doesn't need to be part of the model, one can use the model type X1.

% varargin = [amp_prior, plot_flag, apod_fnc, NUS_flag];

Nr = size(S_t,2);
Nt = length(t);
epsilon = 1e-9;

if isempty(varargin)
    amp_prior = [];
    plot_flag = 0;
    apod_fnc = ones(Nt,1);
else
    if length(varargin) == 1
        amp_prior = varargin{1};
        plot_flag = 1;
        apod_fnc = ones(Nt,1);
        NUS_flag = 0;
    elseif length(varargin) == 2
        amp_prior = varargin{1};
        plot_flag = varargin{2};
        apod_fnc = ones(Nt,1);
        NUS_flag = 0;
    elseif length(varargin) == 3
        amp_prior = varargin{1};
        plot_flag = varargin{2};
        apod_fnc = varargin{3};
        NUS_flag = 0;
    elseif length(varargin) == 4
        amp_prior = varargin{1};
        plot_flag = varargin{2};
        apod_fnc = varargin{3};
        NUS_flag = varargin{4};
    end
    %apod_fnc = varargin{3};
end

mx = Phi_max(1);
% g_model = @(x,M1,t,Nt)reshape(kron(ones(1,M1),apod_fnc),Nt,M1).*...
%     (cos(reshape(2*pi*kron(x(1:M1),t) + ...
%     kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
%     .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));

g_model = @(x,M1,t,Nt)(cos(reshape(2*pi*kron(x(1:M1),t) + ...
    kron(x((2*M1+1):(3*M1)),ones(Nt,1)),Nt,M1))...
    .*exp(-reshape(kron(x((M1+1):2*M1),t),Nt,M1)));

GlobalOptions = opt_options{1};
LocalOptions = opt_options{2};

x_local_X = [];
std_vec = [];

freq_min = Phi_bnds(1,1);
freq_max = Phi_bnds(2,1);

decay_min = Phi_bnds(1,2);
decay_max = Phi_bnds(2,2);

phi_min = Phi_bnds(1,3);
phi_max = Phi_bnds(2,3);


freq_M_00 = x0(1:M_pop0);
decay_M_00 = x0((M_pop0+1):2*M_pop0);
phase_M_00 = x0((2*M_pop0+1):3*M_pop0);


% freq0 = Phi_mean(1); gamma0 = Phi_mean(2); phase0 = Phi_mean(3); 
% sigfreq0 = Phi_sigma(1); siggamma0 = Phi_sigma(2); ...
%     sigphase0 = Phi_sigma(3); 


M_Bayes0 = M_pop0 - 1;
M_Bayes_vec = [];

for i = 1:k_max

    M_Bayes = M_Bayes0 + i;
    freq_M_lb = freq_min*ones(1,M_Bayes); freq_M_ub = freq_max*ones(1,M_Bayes);
    decay_M_lb = decay_min*ones(1,M_Bayes); decay_M_ub = decay_max*ones(1,M_Bayes);
    phase_M_lb = phi_min*ones(1,M_Bayes); phase_M_ub = phi_max*ones(1,M_Bayes);
    

    x0 = [freq_M_00 decay_M_00 phase_M_00];
    lb = [freq_M_lb decay_M_lb phase_M_lb];
    ub = [freq_M_ub decay_M_ub phase_M_ub];

    Phi_min0 = [Phi_min(1)*ones(1,M_Bayes) Phi_min(2)*ones(1,M_Bayes) Phi_min(3)*ones(1,M_Bayes)];
    Phi_max0 = [Phi_max(1)*ones(1,M_Bayes) Phi_max(2)*ones(1,M_Bayes) Phi_max(3)*ones(1,M_Bayes)];

    fun = @(x)ObjFnc_Priors_X1(x,M_Bayes,t,Nt,S_t,epsilon,...
        Phi_min0,Phi_max0,sigstd,amp_prior);

   
    [x_global, ~] = simulannealbnd(fun,x0,lb,ub,GlobalOptions);
    %[x_global, ~] = simulannealbnd(fun,x0,[],[],GlobalOptions);

    fun(x_global)

   

    problem = createOptimProblem('fmincon', 'objective', fun, 'x0', ...
        x_global, 'lb',lb,'ub',ub,'options', LocalOptions);


    [x_local, ~] = fmincon(problem);

    x_local_X{i} = x_local;

    g_rec = g_model(x_local,M_Bayes,t,Nt);
    B_rec = g_rec\S_t;
    S_rec = g_rec*B_rec;

    S_res = S_t - S_rec;
    %S_res_X{i} = S_res;
    
    gamma_filt = 0.0;
    filt = exp(-gamma_filt*t);

    
            
    
            if NUS_flag ~= 0
                % needs to be fixed for imaging data:
                freq_dist_t = abs(nufft(S_res,t*mx));
                v = (0:(Nt-1))/Nt*mx;
            else
                freq_dist_t = abs(fft(sum(S_res.*filt,2),[],1)); % prob distribution from FFT
                freq_dist_t = freq_dist_t(1:Nt/2);
                v = v1(1:Nt/2);
            end

    

    

    [~,r_index] = max(freq_dist_t);


    freq_res_max = v(r_index);


    M_test = 1;


    Phi_min_test = [Phi_min(1)*ones(1,M_test) Phi_min(2)*ones(1,M_test) Phi_min(3)*ones(1,M_test)];
    Phi_max_test = [Phi_max(1)*ones(1,M_test) Phi_max(2)*ones(1,M_test) Phi_max(3)*ones(1,M_test)];

    fun2 = @(x)ObjFnc_Priors_X1(x,M_test,t,Nt,S_res,epsilon,...
        Phi_min_test,Phi_max_test,sigstd,amp_prior);

    x0_2 = [freq_res_max(1) 0 0];
    %lb_2 = [freq_res_max(1)*0.5  1e-3 -pi  tz_lb];
    %ub_2 = [freq_res_max(1)*1.5 dmax pi tz_ub];

    lb_2 = [freq_min decay_min phi_min];
    ub_2 = [freq_max decay_max phi_max];

    [x_global2, ~] = simulannealbnd(fun2,x0_2,lb_2,ub_2,GlobalOptions);


    if plot_flag ~= 0

        std_res = std(S_t(:) - S_rec(:));
        %std_res = mean(std(S_t - S_rec));
        std_vec = [std_vec std_res];
        M_Bayes_vec = [M_Bayes_vec M_Bayes];

        figure(50);
        
        subplot(311); hold off
        plot(M_Bayes_vec,std_vec,'r.-'); hold on
        plot(M_Bayes_vec,sigstd*ones(1,length(M_Bayes_vec)),'g--')
        xlabel('M_{Bayes}')
        title(strcat('{M = }',num2str(M_Bayes)))
        set(gca,'fontsize',20)

        subplot(312); hold off
        plot(t,mean(S_t,2)); hold on
        plot(t,mean(S_rec,2),'r-','linewidth',2)
        xlabel('{\Delta}T (ps)')
        set(gca,'fontsize',20)

        subplot(313); hold off
        plot(v,freq_dist_t);
        text1 = strcat('\omega = ',num2str(x_global2(1),3),'{ THz}',...
            ', \Gamma = ',num2str(x_global2(2),3),'{ THz}');
        title(text1)
        xlabel('v (THz)')
        set(gca,'fontsize',20)
        pause(0.1)

    end

    freq_M_00 = [x_local(1:M_Bayes) x_global2(1)];

    decay_M_00 = [x_local((M_Bayes+1):2*M_Bayes) x_global2(2)];

    phase_M_00 = [x_local((2*M_Bayes+1):3*M_Bayes) x_global2(3)]; 


end